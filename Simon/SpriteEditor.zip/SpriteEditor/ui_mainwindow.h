/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionNew;
    QAction *actionOpen;
    QAction *actionSave;
    QAction *actionExport;
    QAction *actionSettings;
    QAction *actionClose;
    QWidget *centralWidget;
    QGraphicsView *ImageView;
    QGraphicsView *Preview;
    QSlider *FPSSlider;
    QTableWidget *ToolBar;
    QToolButton *BrushButton;
    QToolButton *EraseButton;
    QToolButton *FillButton;
    QToolButton *RectangleButton;
    QToolButton *StampButton;
    QToolButton *LinesButton;
    QPushButton *AddButton;
    QLabel *FramesLabel;
    QLabel *TooLabel;
    QTableView *ToolInfo;
    QPushButton *ExportButton;
    QPushButton *DeleteButton;
    QScrollArea *FrameScrollArea;
    QWidget *ScrollWidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *FrameLayout;
    QPushButton *HelpButton;
    QLabel *FPSLabel;
    QLabel *BrushLabel;
    QLabel *EraseLabel;
    QLabel *FillLabel;
    QLabel *LineLabel;
    QLabel *RectLabel;
    QLabel *StampsLabel;
    QLabel *ColorLabel;
    QPushButton *CustomColorButton;
    QPushButton *Black;
    QPushButton *Grey;
    QPushButton *White;
    QPushButton *Blue;
    QPushButton *Green;
    QPushButton *Yellow;
    QPushButton *Purple;
    QPushButton *Red;
    QLabel *stampsLabel;
    QPushButton *HeartStamp;
    QPushButton *DiamondStamp;
    QPushButton *TriangleStamp;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_4;
    QFrame *line_5;
    QFrame *line_6;
    QFrame *line_7;
    QFrame *line_8;
    QFrame *line_9;
    QFrame *line_10;
    QFrame *line_11;
    QFrame *line_12;
    QFrame *line_13;
    QFrame *line_14;
    QFrame *line_15;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1028, 638);
        actionNew = new QAction(MainWindow);
        actionNew->setObjectName(QStringLiteral("actionNew"));
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        actionExport = new QAction(MainWindow);
        actionExport->setObjectName(QStringLiteral("actionExport"));
        actionSettings = new QAction(MainWindow);
        actionSettings->setObjectName(QStringLiteral("actionSettings"));
        actionClose = new QAction(MainWindow);
        actionClose->setObjectName(QStringLiteral("actionClose"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        ImageView = new QGraphicsView(centralWidget);
        ImageView->setObjectName(QStringLiteral("ImageView"));
        ImageView->setGeometry(QRect(290, 42, 514, 514));
        Preview = new QGraphicsView(centralWidget);
        Preview->setObjectName(QStringLiteral("Preview"));
        Preview->setGeometry(QRect(830, 40, 190, 190));
        FPSSlider = new QSlider(centralWidget);
        FPSSlider->setObjectName(QStringLiteral("FPSSlider"));
        FPSSlider->setGeometry(QRect(840, 230, 160, 18));
        FPSSlider->setMaximum(24);
        FPSSlider->setSliderPosition(1);
        FPSSlider->setOrientation(Qt::Horizontal);
        FPSSlider->setTickPosition(QSlider::TicksBelow);
        FPSSlider->setTickInterval(0);
        ToolBar = new QTableWidget(centralWidget);
        ToolBar->setObjectName(QStringLiteral("ToolBar"));
        ToolBar->setGeometry(QRect(10, 69, 131, 211));
        BrushButton = new QToolButton(centralWidget);
        BrushButton->setObjectName(QStringLiteral("BrushButton"));
        BrushButton->setGeometry(QRect(20, 80, 51, 41));
        EraseButton = new QToolButton(centralWidget);
        EraseButton->setObjectName(QStringLiteral("EraseButton"));
        EraseButton->setGeometry(QRect(80, 80, 51, 41));
        FillButton = new QToolButton(centralWidget);
        FillButton->setObjectName(QStringLiteral("FillButton"));
        FillButton->setGeometry(QRect(20, 150, 51, 41));
        RectangleButton = new QToolButton(centralWidget);
        RectangleButton->setObjectName(QStringLiteral("RectangleButton"));
        RectangleButton->setGeometry(QRect(20, 220, 51, 41));
        StampButton = new QToolButton(centralWidget);
        StampButton->setObjectName(QStringLiteral("StampButton"));
        StampButton->setGeometry(QRect(80, 220, 51, 41));
        LinesButton = new QToolButton(centralWidget);
        LinesButton->setObjectName(QStringLiteral("LinesButton"));
        LinesButton->setGeometry(QRect(80, 150, 51, 41));
        AddButton = new QPushButton(centralWidget);
        AddButton->setObjectName(QStringLiteral("AddButton"));
        AddButton->setGeometry(QRect(150, 70, 41, 31));
        FramesLabel = new QLabel(centralWidget);
        FramesLabel->setObjectName(QStringLiteral("FramesLabel"));
        FramesLabel->setGeometry(QRect(150, 49, 61, 15));
        TooLabel = new QLabel(centralWidget);
        TooLabel->setObjectName(QStringLiteral("TooLabel"));
        TooLabel->setGeometry(QRect(10, 49, 61, 15));
        ToolInfo = new QTableView(centralWidget);
        ToolInfo->setObjectName(QStringLiteral("ToolInfo"));
        ToolInfo->setGeometry(QRect(10, 290, 131, 291));
        ExportButton = new QPushButton(centralWidget);
        ExportButton->setObjectName(QStringLiteral("ExportButton"));
        ExportButton->setGeometry(QRect(870, 280, 90, 26));
        DeleteButton = new QPushButton(centralWidget);
        DeleteButton->setObjectName(QStringLiteral("DeleteButton"));
        DeleteButton->setGeometry(QRect(240, 70, 41, 31));
        FrameScrollArea = new QScrollArea(centralWidget);
        FrameScrollArea->setObjectName(QStringLiteral("FrameScrollArea"));
        FrameScrollArea->setGeometry(QRect(150, 110, 131, 471));
        FrameScrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        FrameScrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        FrameScrollArea->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
        FrameScrollArea->setWidgetResizable(true);
        FrameScrollArea->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        ScrollWidget = new QWidget();
        ScrollWidget->setObjectName(QStringLiteral("ScrollWidget"));
        ScrollWidget->setGeometry(QRect(0, 0, 129, 469));
        ScrollWidget->setLayoutDirection(Qt::LeftToRight);
        verticalLayoutWidget = new QWidget(ScrollWidget);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(0, 0, 131, 471));
        FrameLayout = new QVBoxLayout(verticalLayoutWidget);
        FrameLayout->setSpacing(6);
        FrameLayout->setContentsMargins(11, 11, 11, 11);
        FrameLayout->setObjectName(QStringLiteral("FrameLayout"));
        FrameLayout->setSizeConstraint(QLayout::SetFixedSize);
        FrameLayout->setContentsMargins(6, 5, 6, 6);
        FrameScrollArea->setWidget(ScrollWidget);
        HelpButton = new QPushButton(centralWidget);
        HelpButton->setObjectName(QStringLiteral("HelpButton"));
        HelpButton->setGeometry(QRect(940, 10, 71, 26));
        FPSLabel = new QLabel(centralWidget);
        FPSLabel->setObjectName(QStringLiteral("FPSLabel"));
        FPSLabel->setGeometry(QRect(890, 250, 51, 16));
        BrushLabel = new QLabel(centralWidget);
        BrushLabel->setObjectName(QStringLiteral("BrushLabel"));
        BrushLabel->setGeometry(QRect(20, 120, 41, 16));
        EraseLabel = new QLabel(centralWidget);
        EraseLabel->setObjectName(QStringLiteral("EraseLabel"));
        EraseLabel->setGeometry(QRect(80, 120, 41, 16));
        FillLabel = new QLabel(centralWidget);
        FillLabel->setObjectName(QStringLiteral("FillLabel"));
        FillLabel->setGeometry(QRect(20, 190, 41, 16));
        LineLabel = new QLabel(centralWidget);
        LineLabel->setObjectName(QStringLiteral("LineLabel"));
        LineLabel->setGeometry(QRect(80, 190, 59, 16));
        RectLabel = new QLabel(centralWidget);
        RectLabel->setObjectName(QStringLiteral("RectLabel"));
        RectLabel->setGeometry(QRect(20, 260, 41, 16));
        StampsLabel = new QLabel(centralWidget);
        StampsLabel->setObjectName(QStringLiteral("StampsLabel"));
        StampsLabel->setGeometry(QRect(80, 260, 59, 16));
        ColorLabel = new QLabel(centralWidget);
        ColorLabel->setObjectName(QStringLiteral("ColorLabel"));
        ColorLabel->setGeometry(QRect(20, 300, 41, 16));
        CustomColorButton = new QPushButton(centralWidget);
        CustomColorButton->setObjectName(QStringLiteral("CustomColorButton"));
        CustomColorButton->setGeometry(QRect(60, 290, 81, 41));
        Black = new QPushButton(centralWidget);
        Black->setObjectName(QStringLiteral("Black"));
        Black->setGeometry(QRect(20, 330, 21, 21));
        Grey = new QPushButton(centralWidget);
        Grey->setObjectName(QStringLiteral("Grey"));
        Grey->setGeometry(QRect(50, 330, 21, 21));
        White = new QPushButton(centralWidget);
        White->setObjectName(QStringLiteral("White"));
        White->setGeometry(QRect(80, 330, 21, 21));
        Blue = new QPushButton(centralWidget);
        Blue->setObjectName(QStringLiteral("Blue"));
        Blue->setGeometry(QRect(110, 330, 21, 21));
        Green = new QPushButton(centralWidget);
        Green->setObjectName(QStringLiteral("Green"));
        Green->setGeometry(QRect(20, 360, 21, 21));
        Yellow = new QPushButton(centralWidget);
        Yellow->setObjectName(QStringLiteral("Yellow"));
        Yellow->setGeometry(QRect(50, 360, 21, 21));
        Purple = new QPushButton(centralWidget);
        Purple->setObjectName(QStringLiteral("Purple"));
        Purple->setGeometry(QRect(80, 360, 21, 21));
        Red = new QPushButton(centralWidget);
        Red->setObjectName(QStringLiteral("Red"));
        Red->setGeometry(QRect(110, 360, 21, 21));
        stampsLabel = new QLabel(centralWidget);
        stampsLabel->setObjectName(QStringLiteral("stampsLabel"));
        stampsLabel->setGeometry(QRect(20, 430, 59, 16));
        HeartStamp = new QPushButton(centralWidget);
        HeartStamp->setObjectName(QStringLiteral("HeartStamp"));
        HeartStamp->setGeometry(QRect(20, 450, 31, 32));
        DiamondStamp = new QPushButton(centralWidget);
        DiamondStamp->setObjectName(QStringLiteral("DiamondStamp"));
        DiamondStamp->setGeometry(QRect(60, 450, 31, 32));
        TriangleStamp = new QPushButton(centralWidget);
        TriangleStamp->setObjectName(QStringLiteral("TriangleStamp"));
        TriangleStamp->setGeometry(QRect(100, 450, 31, 32));
        line = new QFrame(centralWidget);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(344, 42, 20, 513));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(centralWidget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setGeometry(QRect(408, 42, 20, 513));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(centralWidget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setGeometry(QRect(472, 42, 20, 513));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        line_4 = new QFrame(centralWidget);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setGeometry(QRect(536, 42, 20, 513));
        line_4->setFrameShape(QFrame::VLine);
        line_4->setFrameShadow(QFrame::Sunken);
        line_5 = new QFrame(centralWidget);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setGeometry(QRect(600, 42, 20, 513));
        line_5->setFrameShape(QFrame::VLine);
        line_5->setFrameShadow(QFrame::Sunken);
        line_6 = new QFrame(centralWidget);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setGeometry(QRect(664, 42, 20, 513));
        line_6->setFrameShape(QFrame::VLine);
        line_6->setFrameShadow(QFrame::Sunken);
        line_7 = new QFrame(centralWidget);
        line_7->setObjectName(QStringLiteral("line_7"));
        line_7->setGeometry(QRect(728, 42, 20, 513));
        line_7->setFrameShape(QFrame::VLine);
        line_7->setFrameShadow(QFrame::Sunken);
        line_8 = new QFrame(centralWidget);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setGeometry(QRect(291, 106, 513, 3));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);
        line_9 = new QFrame(centralWidget);
        line_9->setObjectName(QStringLiteral("line_9"));
        line_9->setGeometry(QRect(290, 170, 513, 3));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);
        line_10 = new QFrame(centralWidget);
        line_10->setObjectName(QStringLiteral("line_10"));
        line_10->setGeometry(QRect(290, 234, 513, 3));
        line_10->setFrameShape(QFrame::HLine);
        line_10->setFrameShadow(QFrame::Sunken);
        line_11 = new QFrame(centralWidget);
        line_11->setObjectName(QStringLiteral("line_11"));
        line_11->setGeometry(QRect(290, 234, 513, 3));
        line_11->setFrameShape(QFrame::HLine);
        line_11->setFrameShadow(QFrame::Sunken);
        line_12 = new QFrame(centralWidget);
        line_12->setObjectName(QStringLiteral("line_12"));
        line_12->setGeometry(QRect(290, 298, 513, 3));
        line_12->setFrameShape(QFrame::HLine);
        line_12->setFrameShadow(QFrame::Sunken);
        line_13 = new QFrame(centralWidget);
        line_13->setObjectName(QStringLiteral("line_13"));
        line_13->setGeometry(QRect(290, 363, 513, 3));
        line_13->setFrameShape(QFrame::HLine);
        line_13->setFrameShadow(QFrame::Sunken);
        line_14 = new QFrame(centralWidget);
        line_14->setObjectName(QStringLiteral("line_14"));
        line_14->setGeometry(QRect(290, 426, 513, 3));
        line_14->setFrameShape(QFrame::HLine);
        line_14->setFrameShadow(QFrame::Sunken);
        line_15 = new QFrame(centralWidget);
        line_15->setObjectName(QStringLiteral("line_15"));
        line_15->setGeometry(QRect(290, 490, 513, 3));
        line_15->setFrameShape(QFrame::HLine);
        line_15->setFrameShadow(QFrame::Sunken);
        MainWindow->setCentralWidget(centralWidget);
        ImageView->raise();
        Preview->raise();
        FPSSlider->raise();
        ToolBar->raise();
        BrushButton->raise();
        EraseButton->raise();
        FillButton->raise();
        RectangleButton->raise();
        StampButton->raise();
        LinesButton->raise();
        FramesLabel->raise();
        TooLabel->raise();
        ToolInfo->raise();
        ExportButton->raise();
        AddButton->raise();
        DeleteButton->raise();
        FrameScrollArea->raise();
        HelpButton->raise();
        FPSLabel->raise();
        BrushLabel->raise();
        EraseLabel->raise();
        FillLabel->raise();
        LineLabel->raise();
        RectLabel->raise();
        StampsLabel->raise();
        ColorLabel->raise();
        CustomColorButton->raise();
        Black->raise();
        Grey->raise();
        White->raise();
        Blue->raise();
        Green->raise();
        Yellow->raise();
        Purple->raise();
        Red->raise();
        stampsLabel->raise();
        HeartStamp->raise();
        DiamondStamp->raise();
        TriangleStamp->raise();
        line->raise();
        line_2->raise();
        line_3->raise();
        line_4->raise();
        line_5->raise();
        line_6->raise();
        line_7->raise();
        line_8->raise();
        line_9->raise();
        line_10->raise();
        line_11->raise();
        line_12->raise();
        line_13->raise();
        line_14->raise();
        line_15->raise();
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1028, 21));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuFile->addAction(actionNew);
        menuFile->addAction(actionOpen);
        menuFile->addAction(actionSave);
        menuFile->addAction(actionExport);
        menuFile->addAction(actionSettings);
        menuFile->addAction(actionClose);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionNew->setText(QApplication::translate("MainWindow", "New", 0));
        actionOpen->setText(QApplication::translate("MainWindow", "Open", 0));
        actionSave->setText(QApplication::translate("MainWindow", "Save", 0));
        actionExport->setText(QApplication::translate("MainWindow", "Export", 0));
        actionSettings->setText(QApplication::translate("MainWindow", "Settings", 0));
        actionClose->setText(QApplication::translate("MainWindow", "Close", 0));
        BrushButton->setText(QString());
        EraseButton->setText(QString());
        FillButton->setText(QString());
        RectangleButton->setText(QString());
        StampButton->setText(QString());
        LinesButton->setText(QString());
        AddButton->setText(QString());
        FramesLabel->setText(QApplication::translate("MainWindow", "Frames", 0));
        TooLabel->setText(QApplication::translate("MainWindow", "Tools", 0));
        ExportButton->setText(QApplication::translate("MainWindow", "Export to Gif", 0));
        DeleteButton->setText(QString());
        HelpButton->setText(QApplication::translate("MainWindow", "Help", 0));
        FPSLabel->setText(QApplication::translate("MainWindow", "1 FPS", 0));
        BrushLabel->setText(QApplication::translate("MainWindow", "Brush", 0));
        EraseLabel->setText(QApplication::translate("MainWindow", "Erase", 0));
        FillLabel->setText(QApplication::translate("MainWindow", "Fill", 0));
        LineLabel->setText(QApplication::translate("MainWindow", "Lines", 0));
        RectLabel->setText(QApplication::translate("MainWindow", "Rect", 0));
        StampsLabel->setText(QApplication::translate("MainWindow", "Stamps", 0));
        ColorLabel->setText(QApplication::translate("MainWindow", "Color:", 0));
        CustomColorButton->setText(QApplication::translate("MainWindow", "Custom", 0));
        Black->setText(QString());
        Grey->setText(QString());
        White->setText(QString());
        Blue->setText(QString());
        Green->setText(QString());
        Yellow->setText(QString());
        Purple->setText(QString());
        Red->setText(QString());
        stampsLabel->setText(QApplication::translate("MainWindow", "Stamps:", 0));
        HeartStamp->setText(QString());
        DiamondStamp->setText(QString());
        TriangleStamp->setText(QString());
        menuFile->setTitle(QApplication::translate("MainWindow", "File", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
