/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[38];
    char stringdata0[588];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 11), // "BrushSignal"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 14), // "AddFrameSignal"
QT_MOC_LITERAL(4, 39, 17), // "DeleteFrameSignal"
QT_MOC_LITERAL(5, 57, 5), // "index"
QT_MOC_LITERAL(6, 63, 12), // "GetFrameSize"
QT_MOC_LITERAL(7, 76, 12), // "UserGridSize"
QT_MOC_LITERAL(8, 89, 12), // "BrushClicked"
QT_MOC_LITERAL(9, 102, 12), // "EraseClicked"
QT_MOC_LITERAL(10, 115, 11), // "FillClicked"
QT_MOC_LITERAL(11, 127, 11), // "LineClicked"
QT_MOC_LITERAL(12, 139, 16), // "RectangleClicked"
QT_MOC_LITERAL(13, 156, 12), // "StampClicked"
QT_MOC_LITERAL(14, 169, 13), // "UpdatePreview"
QT_MOC_LITERAL(15, 183, 10), // "FPSClicked"
QT_MOC_LITERAL(16, 194, 15), // "AddFrameClicked"
QT_MOC_LITERAL(17, 210, 18), // "DeleteFrameClicked"
QT_MOC_LITERAL(18, 229, 16), // "NewFrameSelected"
QT_MOC_LITERAL(19, 246, 22), // "on_actionNew_triggered"
QT_MOC_LITERAL(20, 269, 23), // "on_actionOpen_triggered"
QT_MOC_LITERAL(21, 293, 23), // "on_actionSave_triggered"
QT_MOC_LITERAL(22, 317, 24), // "on_actionClose_triggered"
QT_MOC_LITERAL(23, 342, 21), // "on_HelpButton_clicked"
QT_MOC_LITERAL(24, 364, 18), // "HeartStampSelected"
QT_MOC_LITERAL(25, 383, 20), // "DiamondStampSelected"
QT_MOC_LITERAL(26, 404, 21), // "TriangleStampSelected"
QT_MOC_LITERAL(27, 426, 14), // "CustomSelected"
QT_MOC_LITERAL(28, 441, 13), // "BlackSelected"
QT_MOC_LITERAL(29, 455, 12), // "GreySelected"
QT_MOC_LITERAL(30, 468, 13), // "WhiteSelected"
QT_MOC_LITERAL(31, 482, 12), // "BlueSelected"
QT_MOC_LITERAL(32, 495, 13), // "GreenSelected"
QT_MOC_LITERAL(33, 509, 14), // "YellowSelected"
QT_MOC_LITERAL(34, 524, 12), // "CyanSelected"
QT_MOC_LITERAL(35, 537, 14), // "PurpleSelected"
QT_MOC_LITERAL(36, 552, 11), // "RedSelected"
QT_MOC_LITERAL(37, 564, 23) // "on_ExportButton_clicked"

    },
    "MainWindow\0BrushSignal\0\0AddFrameSignal\0"
    "DeleteFrameSignal\0index\0GetFrameSize\0"
    "UserGridSize\0BrushClicked\0EraseClicked\0"
    "FillClicked\0LineClicked\0RectangleClicked\0"
    "StampClicked\0UpdatePreview\0FPSClicked\0"
    "AddFrameClicked\0DeleteFrameClicked\0"
    "NewFrameSelected\0on_actionNew_triggered\0"
    "on_actionOpen_triggered\0on_actionSave_triggered\0"
    "on_actionClose_triggered\0on_HelpButton_clicked\0"
    "HeartStampSelected\0DiamondStampSelected\0"
    "TriangleStampSelected\0CustomSelected\0"
    "BlackSelected\0GreySelected\0WhiteSelected\0"
    "BlueSelected\0GreenSelected\0YellowSelected\0"
    "CyanSelected\0PurpleSelected\0RedSelected\0"
    "on_ExportButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      35,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  189,    2, 0x06 /* Public */,
       3,    0,  190,    2, 0x06 /* Public */,
       4,    1,  191,    2, 0x06 /* Public */,
       6,    0,  194,    2, 0x06 /* Public */,
       7,    1,  195,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,  198,    2, 0x08 /* Private */,
       9,    0,  199,    2, 0x08 /* Private */,
      10,    0,  200,    2, 0x08 /* Private */,
      11,    0,  201,    2, 0x08 /* Private */,
      12,    0,  202,    2, 0x08 /* Private */,
      13,    0,  203,    2, 0x08 /* Private */,
      14,    0,  204,    2, 0x08 /* Private */,
      15,    0,  205,    2, 0x08 /* Private */,
      16,    0,  206,    2, 0x08 /* Private */,
      17,    0,  207,    2, 0x08 /* Private */,
      18,    1,  208,    2, 0x08 /* Private */,
      19,    0,  211,    2, 0x08 /* Private */,
      20,    0,  212,    2, 0x08 /* Private */,
      21,    0,  213,    2, 0x08 /* Private */,
      22,    0,  214,    2, 0x08 /* Private */,
      23,    0,  215,    2, 0x08 /* Private */,
      24,    0,  216,    2, 0x08 /* Private */,
      25,    0,  217,    2, 0x08 /* Private */,
      26,    0,  218,    2, 0x08 /* Private */,
      27,    0,  219,    2, 0x08 /* Private */,
      28,    0,  220,    2, 0x08 /* Private */,
      29,    0,  221,    2, 0x08 /* Private */,
      30,    0,  222,    2, 0x08 /* Private */,
      31,    0,  223,    2, 0x08 /* Private */,
      32,    0,  224,    2, 0x08 /* Private */,
      33,    0,  225,    2, 0x08 /* Private */,
      34,    0,  226,    2, 0x08 /* Private */,
      35,    0,  227,    2, 0x08 /* Private */,
      36,    0,  228,    2, 0x08 /* Private */,
      37,    0,  229,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->BrushSignal(); break;
        case 1: _t->AddFrameSignal(); break;
        case 2: _t->DeleteFrameSignal((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->GetFrameSize(); break;
        case 4: _t->UserGridSize((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->BrushClicked(); break;
        case 6: _t->EraseClicked(); break;
        case 7: _t->FillClicked(); break;
        case 8: _t->LineClicked(); break;
        case 9: _t->RectangleClicked(); break;
        case 10: _t->StampClicked(); break;
        case 11: _t->UpdatePreview(); break;
        case 12: _t->FPSClicked(); break;
        case 13: _t->AddFrameClicked(); break;
        case 14: _t->DeleteFrameClicked(); break;
        case 15: _t->NewFrameSelected((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_actionNew_triggered(); break;
        case 17: _t->on_actionOpen_triggered(); break;
        case 18: _t->on_actionSave_triggered(); break;
        case 19: _t->on_actionClose_triggered(); break;
        case 20: _t->on_HelpButton_clicked(); break;
        case 21: _t->HeartStampSelected(); break;
        case 22: _t->DiamondStampSelected(); break;
        case 23: _t->TriangleStampSelected(); break;
        case 24: _t->CustomSelected(); break;
        case 25: _t->BlackSelected(); break;
        case 26: _t->GreySelected(); break;
        case 27: _t->WhiteSelected(); break;
        case 28: _t->BlueSelected(); break;
        case 29: _t->GreenSelected(); break;
        case 30: _t->YellowSelected(); break;
        case 31: _t->CyanSelected(); break;
        case 32: _t->PurpleSelected(); break;
        case 33: _t->RedSelected(); break;
        case 34: _t->on_ExportButton_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::BrushSignal)) {
                *result = 0;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::AddFrameSignal)) {
                *result = 1;
            }
        }
        {
            typedef void (MainWindow::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::DeleteFrameSignal)) {
                *result = 2;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::GetFrameSize)) {
                *result = 3;
            }
        }
        {
            typedef void (MainWindow::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::UserGridSize)) {
                *result = 4;
            }
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 35)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 35;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 35)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 35;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::BrushSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void MainWindow::AddFrameSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void MainWindow::DeleteFrameSignal(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MainWindow::GetFrameSize()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void MainWindow::UserGridSize(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_END_MOC_NAMESPACE
