#include "mygraphicsview.h"

#include <QMouseEvent>
#include <iostream>
#include <QGraphicsEffect>


MyGraphicsView::MyGraphicsView(int framePlacement)
{
    this->setBackgroundBrush(QImage(":/background/BackgroundPicture/background.png"));
    this->setCacheMode(QGraphicsView::CacheBackground);

    selected = false;
    placement = framePlacement;
    highlight = new QGraphicsColorizeEffect;
}

MyGraphicsView::~MyGraphicsView()
{
    delete highlight;
}


void MyGraphicsView::mouseReleaseEvent(QMouseEvent *event)
{
    selected = true;
    emit SelectionSignal(placement);
}


void MyGraphicsView::DestroyHighlight()
{
    delete highlight;
}
